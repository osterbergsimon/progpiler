int bar(int x) {
	int x;
        return x;
}
