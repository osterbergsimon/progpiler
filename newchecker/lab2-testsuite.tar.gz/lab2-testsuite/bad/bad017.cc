// 0 instead of 1 argument

int main() {
	int x = foo();
	return 0 ;
}

int foo(int y) {
 return y;
}

