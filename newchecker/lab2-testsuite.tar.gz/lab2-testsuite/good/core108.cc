int main() {
  int j = 4;

  if (j < 6) { 
	printInt(j);
  } else {}

  return j;
}


void printInt(int x) { }
