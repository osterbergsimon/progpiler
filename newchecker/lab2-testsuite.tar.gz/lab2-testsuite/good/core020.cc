void bar() {
	return foo();
}

void foo() {

}
