void bar() {
	return foo();
}

int main () {
  bar() ;
  foo() ;
  return 0 ;

}
void foo() {

}

